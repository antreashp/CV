function visualize(input_image)

end

