function [output_image] = rgb2normedrgb(input_image)
% converts an RGB image into normalized rgb

end

