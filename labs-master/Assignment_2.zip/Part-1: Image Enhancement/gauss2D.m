function G = gauss2D( sigma , kernel_size )
    %% solution
end
