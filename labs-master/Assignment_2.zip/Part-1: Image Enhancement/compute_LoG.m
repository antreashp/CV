function imOut = compute_LoG(image, LOG_type)

switch LOG_type
    case 1
        %method 1
        fprintf('Not implemented\n')

    case 2
        %method 2
        fprintf('Not implemented\n')

    case 3
        %method 3
        fprintf('Not implemented\n')

end
end

