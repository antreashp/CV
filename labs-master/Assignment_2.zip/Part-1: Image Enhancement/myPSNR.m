function [ PSNR ] = myPSNR( orig_image, approx_image )
fprintf('Not implemented\n')

end

